.. _examples:

Examples
--------

.. toctree::
   :maxdepth: 1
   
   Examples/Example_1_function_fitting.rst
   Examples/Example_2_deep_formula.rst
   Examples/Example_3_classfication.rst
   Examples/Example_4_symbolic_regression.rst
   Examples/Example_5_special_functions.rst
   Examples/Example_6_PDE.rst
   Examples/Example_7_continual_learning.rst
   Examples/Example_8_scaling.rst
   Examples/Example_9_singularity.rst
   Examples/Example_10_relativity-addition.rst
   Examples/Example_11_encouraing_linear.rst
   Examples/Example_12_unsupervised_learning.rst
   Examples/Example_13_phase_transition.rst

   