.. _api:

API
===

.. toctree::
   :maxdepth: 4

   kan
